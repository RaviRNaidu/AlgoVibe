import { useState } from 'react';
import { Zap, Code, BookOpen, Gamepad2 } from 'lucide-react';
import BatchMode from './components/BatchMode';
import GameMode from './components/GameMode';
import ExplainMode from './components/ExplainMode';
import GuideCharacter from './components/GuideCharacter';
import { CommandTree } from './lib/graph';

type Mode = 'home' | 'batch' | 'game' | 'explain';

function App() {
  const [mode, setMode] = useState<Mode>('home');
  const [explainTree, setExplainTree] = useState<CommandTree | null>(null);
  const [guideMessage, setGuideMessage] = useState<{ text: string; emotion: 'idle' | 'point' | 'celebrate' } | null>(null);

  const showGuideMessage = (text: string, emotion: 'idle' | 'point' | 'celebrate' = 'idle') => {
    setGuideMessage({ text, emotion });
  };

  const handleModeChange = (newMode: Mode) => {
    setMode(newMode);

    if (newMode === 'batch') {
      showGuideMessage("Batch mode lets you process multiple commands at once. Paste your input and watch the tree grow!", 'point');
    } else if (newMode === 'game') {
      showGuideMessage("I am Lumen — the strategist. Place commands wisely and watch influence bloom.", 'celebrate');
    }
  };

  if (mode === 'explain' && explainTree) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
        <ExplainMode
          tree={explainTree}
          onClose={() => {
            setMode('home');
            setExplainTree(null);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      <header className="bg-slate-900/50 backdrop-blur-sm border-b border-slate-800 shadow-xl">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => handleModeChange('home')}
              className="flex items-center gap-3 group"
            >
              <div className="relative">
                <Zap className="w-8 h-8 text-purple-500 group-hover:text-purple-400 transition-colors" />
                <div className="absolute inset-0 bg-purple-500 blur-xl opacity-50 group-hover:opacity-75 transition-opacity" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
                  Command Chain
                </h1>
                <p className="text-xs text-slate-400">Geass Command Tree</p>
              </div>
            </button>

            <nav className="flex gap-2">
              <button
                onClick={() => handleModeChange('batch')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                  mode === 'batch'
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Code className="w-4 h-4" />
                Batch Mode
              </button>
              <button
                onClick={() => handleModeChange('game')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                  mode === 'game'
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Gamepad2 className="w-4 h-4" />
                Game Mode
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto h-[calc(100vh-80px)]">
        {mode === 'home' && (
          <div className="h-full flex items-center justify-center p-6">
            <div className="max-w-4xl w-full">
              <div className="text-center mb-12">
                <div className="inline-block relative mb-6">
                  <Zap className="w-20 h-20 text-purple-500 mx-auto" />
                  <div className="absolute inset-0 bg-purple-500 blur-3xl opacity-50" />
                </div>
                <h2 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-purple-600 mb-4">
                  Command Chain
                </h2>
                <p className="text-xl text-slate-300 mb-2">
                  Master the Geass Command Tree Algorithm
                </p>
                <p className="text-slate-400 max-w-2xl mx-auto">
                  Build command hierarchies, compute subtree sizes in O(1), and learn through interactive gameplay.
                  Perfect for CS students and competitive programmers.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <button
                  onClick={() => handleModeChange('batch')}
                  className="group bg-slate-800 border-2 border-slate-700 hover:border-blue-500 rounded-xl p-6 text-left transition-all hover:shadow-2xl hover:shadow-blue-500/20"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-lg group-hover:bg-blue-500/30 transition-colors">
                      <Code className="w-8 h-8 text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-slate-100 mb-2">Batch Mode</h3>
                      <p className="text-slate-400 text-sm mb-3">
                        Process multiple INSERT and QUERY operations at once. Perfect for testing and understanding the algorithm.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-300 rounded">Fast Processing</span>
                        <span className="text-xs px-2 py-1 bg-blue-500/20 text-blue-300 rounded">O(N) Complexity</span>
                      </div>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => handleModeChange('game')}
                  className="group bg-slate-800 border-2 border-slate-700 hover:border-purple-500 rounded-xl p-6 text-left transition-all hover:shadow-2xl hover:shadow-purple-500/20"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-purple-500/20 rounded-lg group-hover:bg-purple-500/30 transition-colors">
                      <Gamepad2 className="w-8 h-8 text-purple-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-slate-100 mb-2">Game Mode</h3>
                      <p className="text-slate-400 text-sm mb-3">
                        Interactive placement puzzle. Build the command tree by correctly placing nodes under their commanders.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <span className="text-xs px-2 py-1 bg-purple-500/20 text-purple-300 rounded">Scoring</span>
                        <span className="text-xs px-2 py-1 bg-purple-500/20 text-purple-300 rounded">Combos</span>
                        <span className="text-xs px-2 py-1 bg-purple-500/20 text-purple-300 rounded">3 Levels</span>
                      </div>
                    </div>
                  </div>
                </button>
              </div>

              <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <BookOpen className="w-6 h-6 text-green-400 mt-1" />
                  <div>
                    <h3 className="text-lg font-bold text-slate-100 mb-2">How It Works</h3>
                    <ul className="space-y-2 text-slate-300 text-sm">
                      <li className="flex gap-2">
                        <span className="text-green-400">•</span>
                        <span>Build a rooted tree with ROOT as Lelouch (the supreme commander)</span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-green-400">•</span>
                        <span>Use iterative DFS to compute subtree sizes (nodes influenced by each commander)</span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-green-400">•</span>
                        <span>Answer QUERY X in O(1) time after O(N) preprocessing</span>
                      </li>
                      <li className="flex gap-2">
                        <span className="text-green-400">•</span>
                        <span>Supports up to 100,000 nodes efficiently</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="mt-6 text-center">
                <p className="text-slate-500 text-sm">
                  Built for educational purposes • Supports batch processing and interactive learning
                </p>
              </div>
            </div>
          </div>
        )}

        {mode === 'batch' && <BatchMode />}
        {mode === 'game' && <GameMode />}
      </main>

      <GuideCharacter message={guideMessage} />
    </div>
  );
}

export default App;
