import { useState, useEffect } from 'react';
import { CommandTree } from '../lib/graph';
import TreeVisualization from './TreeVisualization';
import { Play, SkipForward, RotateCcw, Pause } from 'lucide-react';

interface ExplainModeProps {
  tree: CommandTree;
  onClose: () => void;
}

interface AnimationStep {
  nodeId: string;
  phase: 'enter' | 'exit';
  explanation: string;
}

export default function ExplainMode({ tree, onClose }: ExplainModeProps) {
  const [steps, setSteps] = useState<AnimationStep[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [highlightNode, setHighlightNode] = useState<string | null>(null);

  useEffect(() => {
    generateSteps();
  }, [tree]);

  useEffect(() => {
    if (steps.length > 0 && currentStep < steps.length) {
      setHighlightNode(steps[currentStep].nodeId);
    }
  }, [currentStep, steps]);

  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentStep(prev => {
        if (prev >= steps.length - 1) {
          setIsPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isPlaying, steps.length]);

  const generateSteps = () => {
    const animSteps: AnimationStep[] = [];
    const root = tree.getNode('ROOT');
    if (!root) return;

    const traverse = (nodeId: string, phase: 'enter' | 'exit') => {
      const node = tree.getNode(nodeId);
      if (!node) return;

      if (phase === 'enter') {
        animSteps.push({
          nodeId,
          phase: 'enter',
          explanation: nodeId === 'ROOT'
            ? `Starting DFS traversal from ROOT (Lelouch). Depth = 0.`
            : `Visiting node ${nodeId}. Depth = ${node.depth}. We'll explore its subtree.`
        });

        for (const childId of node.children) {
          traverse(childId, 'enter');
        }

        animSteps.push({
          nodeId,
          phase: 'exit',
          explanation: nodeId === 'ROOT'
            ? `Completed DFS. ROOT has ${node.children.length} direct subordinates and subtree size ${node.subtreeSize}.`
            : `Exiting ${nodeId}. Computed subtree size = ${node.subtreeSize} (sum of children + their subtrees).`
        });
      }
    };

    traverse('ROOT', 'enter');
    setSteps(animSteps);
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleReset = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  const handlePlayPause = () => {
    setIsPlaying(prev => !prev);
  };

  if (steps.length === 0) {
    return (
      <div className="h-full flex items-center justify-center p-6">
        <p className="text-slate-400">Generating explanation...</p>
      </div>
    );
  }

  const currentStepData = steps[currentStep];

  return (
    <div className="h-full flex flex-col lg:flex-row gap-4 p-6">
      <div className="lg:w-1/3 flex flex-col gap-4">
        <div className="bg-slate-800 rounded-lg p-4 shadow-xl border border-slate-700">
          <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600 mb-4">
            Algorithm Explanation
          </h3>

          <div className="bg-slate-900 p-4 rounded-lg mb-4 border border-slate-700">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Step {currentStep + 1} of {steps.length}</span>
              <span className={`text-xs px-2 py-1 rounded ${
                currentStepData.phase === 'enter' ? 'bg-blue-500/20 text-blue-300' : 'bg-green-500/20 text-green-300'
              }`}>
                {currentStepData.phase === 'enter' ? 'Entering' : 'Exiting'}
              </span>
            </div>
            <p className="text-slate-100 text-sm leading-relaxed">
              {currentStepData.explanation}
            </p>
          </div>

          <div className="flex gap-2 mb-4">
            <button
              onClick={handlePlayPause}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              onClick={handleNext}
              disabled={currentStep >= steps.length - 1}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-700 text-white font-bold rounded-lg hover:bg-slate-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <SkipForward className="w-5 h-5" />
            </button>
            <button
              onClick={handleReset}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-700 text-white font-bold rounded-lg hover:bg-slate-600 transition-all"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          <div className="bg-slate-900 p-4 rounded-lg border border-slate-700">
            <h4 className="text-sm font-bold text-slate-200 mb-3">DFS Algorithm Overview</h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex gap-2">
                <span className="text-blue-400">1.</span>
                <span>Start at ROOT node</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-400">2.</span>
                <span>Visit each child recursively</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-400">3.</span>
                <span>On exit, sum children subtree sizes</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-400">4.</span>
                <span>Store result for O(1) queries</span>
              </li>
            </ul>
          </div>

          <div className="mt-4 p-4 bg-purple-900/30 border border-purple-500 rounded-lg">
            <h4 className="text-sm font-bold text-purple-200 mb-2">Complexity</h4>
            <div className="space-y-1 text-xs text-purple-100">
              <p><span className="font-semibold">Time:</span> O(N) preprocessing</p>
              <p><span className="font-semibold">Query:</span> O(1) per query</p>
              <p><span className="font-semibold">Space:</span> O(N)</p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 bg-slate-700 text-white font-bold rounded-lg hover:bg-slate-600 transition-all"
        >
          Close Explanation
        </button>
      </div>

      <div className="lg:w-2/3 h-[600px] lg:h-full">
        <TreeVisualization
          data={tree.getTreeData()}
          highlightNode={highlightNode}
          animateInsertion={false}
          showLabels={true}
        />
      </div>
    </div>
  );
}
