import { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';

interface GuideMessage {
  text: string;
  emotion: 'idle' | 'point' | 'celebrate';
}

interface GuideCharacterProps {
  message?: GuideMessage | null;
  autoHide?: boolean;
}

export default function GuideCharacter({ message, autoHide = true }: GuideCharacterProps) {
  const [visible, setVisible] = useState(!!message);
  const [currentMessage, setCurrentMessage] = useState<GuideMessage | null>(message || null);

  useEffect(() => {
    if (message) {
      setCurrentMessage(message);
      setVisible(true);

      if (autoHide) {
        const timer = setTimeout(() => {
          setVisible(false);
        }, 4000);
        return () => clearTimeout(timer);
      }
    }
  }, [message, autoHide]);

  if (!visible || !currentMessage) return null;

  return (
    <div className="fixed bottom-8 left-8 z-50 flex items-end gap-4 animate-fadeIn">
      <div className="relative">
        <div className={`w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center shadow-2xl border-4 border-white/20 transition-transform ${
          currentMessage.emotion === 'celebrate' ? 'animate-bounce' : 'animate-pulse'
        }`}>
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-300 to-pink-400 flex items-center justify-center">
              <div className="text-4xl">✨</div>
            </div>

            {currentMessage.emotion === 'celebrate' && (
              <div className="absolute -top-2 -right-2">
                <Sparkles className="w-6 h-6 text-yellow-300 animate-spin" />
              </div>
            )}
          </div>
        </div>

        <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-slate-900 animate-pulse" />
      </div>

      <div className="bg-slate-800 border-2 border-purple-500/50 rounded-2xl p-4 max-w-sm shadow-2xl relative">
        <div className="absolute -left-2 bottom-6 w-0 h-0 border-t-8 border-t-transparent border-b-8 border-b-transparent border-r-8 border-r-slate-800" />

        <div className="flex items-start gap-2 mb-2">
          <div className="flex-1">
            <h4 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
              Lumen
            </h4>
            <p className="text-xs text-slate-400">Strategist Guide</p>
          </div>
        </div>

        <p className="text-slate-100 text-sm leading-relaxed">
          {currentMessage.text}
        </p>

        <div className="mt-3 flex gap-1">
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse delay-100" />
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse delay-200" />
        </div>
      </div>
    </div>
  );
}
