import { useState } from 'react';
import { CommandTree, parseBatchInput } from '../lib/graph';
import TreeVisualization from './TreeVisualization';
import { Play, FileText } from 'lucide-react';

export default function BatchMode() {
  const [input, setInput] = useState<string>(
    `7
INSERT A ROOT
INSERT B ROOT
INSERT C A
INSERT D A
INSERT E B
INSERT F B
INSERT G C
QUERY A
QUERY B
QUERY ROOT`
  );
  const [output, setOutput] = useState<string>('');
  const [tree, setTree] = useState<CommandTree | null>(null);
  const [processing, setProcessing] = useState(false);

  const handleRun = () => {
    setProcessing(true);
    setTimeout(() => {
      try {
        const { inserts, queries } = parseBatchInput(input);
        const commandTree = new CommandTree();
        const results: string[] = [];

        for (const [person, commander] of inserts) {
          const success = commandTree.addInsert(person, commander);
          if (!success) {
            results.push(`Error: Could not insert ${person} under ${commander}`);
          }
        }

        commandTree.computeSizesAndDepths();

        for (const personId of queries) {
          const result = commandTree.query(personId);
          if (result !== null) {
            results.push(`${result}`);
          } else {
            results.push(`Error: Node ${personId} not found`);
          }
        }

        setOutput(results.join('\n'));
        setTree(commandTree);
      } catch (error) {
        setOutput(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
        setTree(null);
      }
      setProcessing(false);
    }, 100);
  };

  return (
    <div className="h-full flex flex-col lg:flex-row gap-4 p-6">
      <div className="lg:w-1/3 flex flex-col gap-4">
        <div className="flex-1 flex flex-col bg-slate-800 rounded-lg p-4 shadow-xl border border-slate-700">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" />
              <h3 className="text-lg font-bold text-slate-100">Input</h3>
            </div>
            <button
              onClick={handleRun}
              disabled={processing}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Play className="w-4 h-4" />
              {processing ? 'Processing...' : 'Run'}
            </button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 w-full bg-slate-900 text-slate-100 font-mono text-sm p-3 rounded border border-slate-700 focus:border-blue-500 focus:outline-none resize-none"
            placeholder="Enter commands here..."
            spellCheck={false}
          />
          <div className="mt-3 text-xs text-slate-400 space-y-1">
            <p>Format: INSERT X Y or QUERY X</p>
            <p>First line can be N (number of operations)</p>
          </div>
        </div>

        <div className="flex-1 flex flex-col bg-slate-800 rounded-lg p-4 shadow-xl border border-slate-700">
          <h3 className="text-lg font-bold text-slate-100 mb-3">Output</h3>
          <div className="flex-1 w-full bg-slate-900 text-green-400 font-mono text-sm p-3 rounded border border-slate-700 overflow-auto whitespace-pre">
            {output || 'Results will appear here...'}
          </div>
        </div>
      </div>

      <div className="lg:w-2/3 h-[600px] lg:h-full">
        {tree ? (
          <TreeVisualization
            data={tree.getTreeData()}
            animateInsertion={true}
            showLabels={true}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-slate-800 rounded-lg border border-slate-700">
            <p className="text-slate-400">Run your input to see the tree visualization</p>
          </div>
        )}
      </div>
    </div>
  );
}
