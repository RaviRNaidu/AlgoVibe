import { useState, useEffect } from 'react';
import { CommandTree, generateLevel } from '../lib/graph';
import TreeVisualization from './TreeVisualization';
import { Play, Timer, Trophy, Zap, CheckCircle, XCircle, Target } from 'lucide-react';

type Difficulty = 'easy' | 'medium' | 'hard';

interface PlacementTask {
  nodeId: string;
  expectedParent: string;
  placed: boolean;
  correct: boolean | null;
}

export default function GameMode() {
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [gameState, setGameState] = useState<'setup' | 'playing' | 'completed'>('setup');
  const [groundTruth, setGroundTruth] = useState<CommandTree | null>(null);
  const [playerTree, setPlayerTree] = useState<CommandTree | null>(null);
  const [tasks, setTasks] = useState<PlacementTask[]>([]);
  const [currentTaskIndex, setCurrentTaskIndex] = useState(0);
  const [selectedParent, setSelectedParent] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [queryMode, setQueryMode] = useState(false);
  const [currentQuery, setCurrentQuery] = useState<string | null>(null);
  const [queryAnswer, setQueryAnswer] = useState<string>('');

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (gameState === 'playing') {
      interval = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [gameState]);

  const startGame = () => {
    const { groundTruth: gt, shuffledInserts, queryTargets } = generateLevel(difficulty);

    setGroundTruth(gt);
    setPlayerTree(new CommandTree());

    const taskList: PlacementTask[] = shuffledInserts.map(([nodeId, parent]) => ({
      nodeId,
      expectedParent: parent,
      placed: false,
      correct: null
    }));

    setTasks(taskList);
    setCurrentTaskIndex(0);
    setScore(0);
    setCombo(0);
    setTimeElapsed(0);
    setGameState('playing');
    setMessage({ text: "Place nodes under their commanders. Click a node in the tree to select it as parent!", type: 'info' });
    setQueryMode(false);
    setCurrentQuery(null);
  };

  const handleNodeClick = (nodeId: string) => {
    if (queryMode) {
      setCurrentQuery(nodeId);
      return;
    }

    if (gameState !== 'playing' || currentTaskIndex >= tasks.length) return;

    setSelectedParent(nodeId);
  };

  const handlePlace = () => {
    if (!selectedParent || !playerTree || !groundTruth) return;

    const currentTask = tasks[currentTaskIndex];
    const isCorrect = selectedParent === currentTask.expectedParent;

    playerTree.addInsert(currentTask.nodeId, selectedParent);
    playerTree.computeSizesAndDepths();

    const updatedTasks = [...tasks];
    updatedTasks[currentTaskIndex] = {
      ...currentTask,
      placed: true,
      correct: isCorrect
    };
    setTasks(updatedTasks);

    if (isCorrect) {
      const comboBonus = combo * 10;
      const baseScore = 100;
      const timeBonus = Math.max(0, 50 - timeElapsed);
      const totalPoints = baseScore + comboBonus + timeBonus;

      setScore(prev => prev + totalPoints);
      setCombo(prev => prev + 1);
      setMessage({
        text: `Perfect! The command ripples outward. +${totalPoints} pts ${combo > 0 ? `(${combo}x combo!)` : ''}`,
        type: 'success'
      });
    } else {
      setCombo(0);
      setScore(prev => Math.max(0, prev - 25));
      setMessage({ text: "That breaks the chain — think causally! -25 pts", type: 'error' });
    }

    setSelectedParent(null);

    if (currentTaskIndex < tasks.length - 1) {
      setTimeout(() => {
        setCurrentTaskIndex(prev => prev + 1);
        setMessage(null);
      }, 1500);
    } else {
      setTimeout(() => {
        setGameState('completed');
        setMessage({ text: "Level Complete! All commands placed.", type: 'success' });
      }, 1500);
    }
  };

  const handleQuerySubmit = () => {
    if (!currentQuery || !groundTruth) return;

    const correctAnswer = groundTruth.query(currentQuery);
    const userAnswer = parseInt(queryAnswer);

    if (correctAnswer !== null && userAnswer === correctAnswer) {
      setScore(prev => prev + 200);
      setMessage({
        text: `Correct! Node ${currentQuery} has subtree size ${correctAnswer}. +200 pts`,
        type: 'success'
      });
    } else {
      setMessage({
        text: `Wrong! Node ${currentQuery} has subtree size ${correctAnswer}, not ${userAnswer}.`,
        type: 'error'
      });
    }

    setQueryMode(false);
    setCurrentQuery(null);
    setQueryAnswer('');
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (gameState === 'setup') {
    return (
      <div className="h-full flex items-center justify-center p-6">
        <div className="max-w-2xl w-full bg-slate-800 rounded-lg p-8 shadow-2xl border border-slate-700">
          <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600 mb-6">
            Placement Puzzle Mode
          </h2>
          <p className="text-slate-300 mb-6">
            Build the command tree by placing nodes under their correct commanders.
            Use quick thinking and maintain combos for bonus points!
          </p>

          <div className="space-y-4 mb-8">
            <label className="block text-slate-200 font-semibold mb-2">Select Difficulty:</label>
            <div className="grid grid-cols-3 gap-4">
              {(['easy', 'medium', 'hard'] as Difficulty[]).map(d => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`py-3 px-4 rounded-lg font-semibold transition-all ${
                    difficulty === d
                      ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg'
                      : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                  }`}
                >
                  {d.charAt(0).toUpperCase() + d.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={startGame}
            className="w-full flex items-center justify-center gap-3 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-lg font-bold rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg"
          >
            <Play className="w-6 h-6" />
            Start Game
          </button>
        </div>
      </div>
    );
  }

  const currentTask = tasks[currentTaskIndex];
  const progress = tasks.filter(t => t.placed).length;

  return (
    <div className="h-full flex flex-col lg:flex-row gap-4 p-6">
      <div className="lg:w-1/4 flex flex-col gap-4">
        <div className="bg-slate-800 rounded-lg p-4 shadow-xl border border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-400" />
              <span className="text-2xl font-bold text-slate-100">{score}</span>
            </div>
            <div className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-blue-400" />
              <span className="text-lg text-slate-300">{formatTime(timeElapsed)}</span>
            </div>
          </div>

          {combo > 1 && (
            <div className="flex items-center gap-2 mb-4 bg-gradient-to-r from-orange-500 to-red-600 text-white px-3 py-2 rounded-lg">
              <Zap className="w-5 h-5" />
              <span className="font-bold">{combo}x Combo!</span>
            </div>
          )}

          <div className="mb-4">
            <div className="flex justify-between text-sm text-slate-400 mb-1">
              <span>Progress</span>
              <span>{progress}/{tasks.length}</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all"
                style={{ width: `${(progress / tasks.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {gameState === 'playing' && currentTask && (
          <div className="bg-slate-800 rounded-lg p-4 shadow-xl border border-slate-700">
            <h3 className="text-lg font-bold text-slate-100 mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-400" />
              Current Task
            </h3>
            <div className="bg-slate-900 p-4 rounded-lg mb-4">
              <p className="text-slate-300 text-sm mb-2">Place node:</p>
              <p className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
                {currentTask.nodeId}
              </p>
            </div>

            {selectedParent && (
              <div className="bg-purple-900/30 border border-purple-500 p-3 rounded-lg mb-3">
                <p className="text-sm text-purple-200 mb-1">Selected parent:</p>
                <p className="text-lg font-bold text-purple-100">{selectedParent}</p>
              </div>
            )}

            <button
              onClick={handlePlace}
              disabled={!selectedParent}
              className="w-full py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-lg hover:from-green-600 hover:to-emerald-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Place Node
            </button>
          </div>
        )}

        {message && (
          <div className={`rounded-lg p-4 shadow-xl border ${
            message.type === 'success'
              ? 'bg-green-900/30 border-green-500'
              : message.type === 'error'
              ? 'bg-red-900/30 border-red-500'
              : 'bg-blue-900/30 border-blue-500'
          }`}>
            <p className="text-sm text-slate-100">{message.text}</p>
          </div>
        )}

        <div className="bg-slate-800 rounded-lg p-4 shadow-xl border border-slate-700">
          <h3 className="text-sm font-bold text-slate-100 mb-2">Task History</h3>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {tasks.map((task, idx) => (
              <div
                key={idx}
                className={`flex items-center justify-between text-xs p-2 rounded ${
                  idx === currentTaskIndex ? 'bg-purple-900/30 border border-purple-500' : 'bg-slate-900'
                }`}
              >
                <span className="text-slate-300">{task.nodeId}</span>
                {task.placed && (
                  task.correct ? (
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-400" />
                  )
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="lg:w-3/4 h-[600px] lg:h-full">
        {playerTree && (
          <TreeVisualization
            data={playerTree.getTreeData()}
            onNodeClick={handleNodeClick}
            highlightNode={selectedParent || undefined}
            animateInsertion={false}
            showLabels={true}
          />
        )}
      </div>
    </div>
  );
}
