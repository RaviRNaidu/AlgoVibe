import { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface TreeNode {
  name: string;
  id: string;
  depth: number;
  subtreeSize: number;
  children?: TreeNode[];
}

interface TreeVisualizationProps {
  data: TreeNode | null;
  highlightNode?: string | null;
  onNodeClick?: (nodeId: string) => void;
  animateInsertion?: boolean;
  showLabels?: boolean;
}

export default function TreeVisualization({
  data,
  highlightNode,
  onNodeClick,
  animateInsertion = false,
  showLabels = true
}: TreeVisualizationProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!data || !svgRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    d3.select(svgRef.current).selectAll('*').remove();

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);

    const g = svg.append('g');

    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.3, 3])
      .on('zoom', (event) => {
        g.attr('transform', event.transform);
      });

    svg.call(zoom);

    const treeLayout = d3.tree<TreeNode>()
      .size([width - 100, height - 150])
      .separation((a, b) => (a.parent === b.parent ? 1 : 1.2));

    const root = d3.hierarchy(data);
    const treeData = treeLayout(root);

    const maxDepth = d3.max(treeData.descendants(), d => d.depth) || 1;

    const links = g.selectAll('.link')
      .data(treeData.links())
      .enter()
      .append('path')
      .attr('class', 'link')
      .attr('fill', 'none')
      .attr('stroke', (d: any) => {
        const depth = d.target.depth;
        return d3.interpolateViridis(depth / maxDepth);
      })
      .attr('stroke-width', 2)
      .attr('opacity', 0.6)
      .attr('d', d3.linkVertical<any, any>()
        .x(d => d.x + 50)
        .y(d => d.y + 75));

    if (animateInsertion) {
      links.attr('stroke-dasharray', function() {
        const length = (this as SVGPathElement).getTotalLength();
        return `${length} ${length}`;
      })
      .attr('stroke-dashoffset', function() {
        return (this as SVGPathElement).getTotalLength();
      })
      .transition()
      .duration(1000)
      .ease(d3.easeCubicInOut)
      .attr('stroke-dashoffset', 0);
    }

    const nodes = g.selectAll('.node')
      .data(treeData.descendants())
      .enter()
      .append('g')
      .attr('class', 'node')
      .attr('transform', d => `translate(${d.x + 50},${d.y + 75})`)
      .style('cursor', onNodeClick ? 'pointer' : 'default')
      .on('click', (event, d) => {
        if (onNodeClick) {
          event.stopPropagation();
          onNodeClick(d.data.id);
        }
      });

    if (animateInsertion) {
      nodes.attr('opacity', 0)
        .transition()
        .duration(800)
        .delay((d, i) => i * 50)
        .attr('opacity', 1);
    }

    nodes.append('circle')
      .attr('r', 0)
      .attr('fill', (d: any) => {
        if (highlightNode && d.data.id === highlightNode) {
          return '#fbbf24';
        }
        const depth = d.depth;
        return d3.interpolateCool(depth / maxDepth);
      })
      .attr('stroke', '#1e293b')
      .attr('stroke-width', 2)
      .transition()
      .duration(500)
      .attr('r', (d: any) => d.data.id === 'ROOT' ? 20 : 16);

    nodes.filter((d: any) => highlightNode && d.data.id === highlightNode)
      .append('circle')
      .attr('r', 16)
      .attr('fill', 'none')
      .attr('stroke', '#fbbf24')
      .attr('stroke-width', 3)
      .attr('opacity', 0.8)
      .transition()
      .duration(1000)
      .attr('r', 30)
      .attr('opacity', 0);

    if (showLabels) {
      nodes.append('text')
        .attr('dy', -25)
        .attr('text-anchor', 'middle')
        .attr('fill', '#f1f5f9')
        .attr('font-size', '12px')
        .attr('font-weight', 'bold')
        .text((d: any) => d.data.name);

      nodes.append('text')
        .attr('dy', 35)
        .attr('text-anchor', 'middle')
        .attr('fill', '#cbd5e1')
        .attr('font-size', '10px')
        .text((d: any) => `Subtree: ${d.data.subtreeSize}`);
    }

    const initialTransform = d3.zoomIdentity
      .translate(width / 2 - 50, 50)
      .scale(1);

    svg.call(zoom.transform, initialTransform);

  }, [data, highlightNode, onNodeClick, animateInsertion, showLabels]);

  return (
    <div ref={containerRef} className="w-full h-full relative bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 rounded-lg overflow-hidden">
      <svg ref={svgRef} className="w-full h-full" />
      <div className="absolute bottom-4 right-4 text-slate-400 text-xs bg-slate-900/50 px-3 py-2 rounded">
        Scroll to zoom • Drag to pan
      </div>
    </div>
  );
}
