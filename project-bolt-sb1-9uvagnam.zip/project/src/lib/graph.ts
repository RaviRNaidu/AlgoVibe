export interface TreeNode {
  id: string;
  parent: string | null;
  children: string[];
  depth: number;
  subtreeSize: number;
}

export class CommandTree {
  private nodes: Map<string, TreeNode>;
  private root: string = 'ROOT';
  private computed: boolean = false;

  constructor() {
    this.nodes = new Map();
    this.nodes.set(this.root, {
      id: this.root,
      parent: null,
      children: [],
      depth: 0,
      subtreeSize: 0
    });
  }

  addInsert(personId: string, commanderId: string): boolean {
    if (this.nodes.has(personId)) {
      return false;
    }

    const commander = this.nodes.get(commanderId);
    if (!commander) {
      return false;
    }

    const newNode: TreeNode = {
      id: personId,
      parent: commanderId,
      children: [],
      depth: 0,
      subtreeSize: 0
    };

    this.nodes.set(personId, newNode);
    commander.children.push(personId);
    this.computed = false;

    return true;
  }

  computeSizesAndDepths(): void {
    const stack: Array<{ nodeId: string; phase: 'enter' | 'exit' }> = [
      { nodeId: this.root, phase: 'enter' }
    ];
    const visited = new Set<string>();

    while (stack.length > 0) {
      const current = stack.pop()!;
      const node = this.nodes.get(current.nodeId)!;

      if (current.phase === 'enter') {
        if (visited.has(current.nodeId)) continue;
        visited.add(current.nodeId);

        if (node.parent !== null) {
          const parentNode = this.nodes.get(node.parent)!;
          node.depth = parentNode.depth + 1;
        }

        stack.push({ nodeId: current.nodeId, phase: 'exit' });

        for (let i = node.children.length - 1; i >= 0; i--) {
          stack.push({ nodeId: node.children[i], phase: 'enter' });
        }
      } else {
        let totalSize = 0;
        for (const childId of node.children) {
          const child = this.nodes.get(childId)!;
          totalSize += 1 + child.subtreeSize;
        }
        node.subtreeSize = totalSize;
      }
    }

    this.computed = true;
  }

  query(personId: string): number | null {
    if (!this.computed) {
      this.computeSizesAndDepths();
    }

    const node = this.nodes.get(personId);
    return node ? node.subtreeSize : null;
  }

  getNode(id: string): TreeNode | undefined {
    return this.nodes.get(id);
  }

  getAllNodes(): TreeNode[] {
    return Array.from(this.nodes.values());
  }

  getTreeData(): any {
    if (!this.computed) {
      this.computeSizesAndDepths();
    }

    const buildHierarchy = (nodeId: string): any => {
      const node = this.nodes.get(nodeId)!;
      return {
        name: nodeId,
        id: nodeId,
        depth: node.depth,
        subtreeSize: node.subtreeSize,
        children: node.children.map(childId => buildHierarchy(childId))
      };
    };

    return buildHierarchy(this.root);
  }

  reset(): void {
    this.nodes.clear();
    this.nodes.set(this.root, {
      id: this.root,
      parent: null,
      children: [],
      depth: 0,
      subtreeSize: 0
    });
    this.computed = false;
  }

  clone(): CommandTree {
    const newTree = new CommandTree();
    newTree.nodes = new Map();

    for (const [id, node] of this.nodes.entries()) {
      newTree.nodes.set(id, {
        ...node,
        children: [...node.children]
      });
    }

    newTree.computed = this.computed;
    return newTree;
  }
}

export function parseBatchInput(input: string): { inserts: Array<[string, string]>, queries: string[] } {
  const lines = input.trim().split('\n').map(line => line.trim()).filter(line => line.length > 0);
  const inserts: Array<[string, string]> = [];
  const queries: string[] = [];

  let startIndex = 0;
  if (lines.length > 0 && !isNaN(Number(lines[0]))) {
    startIndex = 1;
  }

  for (let i = startIndex; i < lines.length; i++) {
    const parts = lines[i].split(/\s+/);
    if (parts[0] === 'INSERT' && parts.length === 3) {
      inserts.push([parts[1], parts[2]]);
    } else if (parts[0] === 'QUERY' && parts.length === 2) {
      queries.push(parts[1]);
    }
  }

  return { inserts, queries };
}

export function generateLevel(difficulty: 'easy' | 'medium' | 'hard'): {
  groundTruth: CommandTree,
  shuffledInserts: Array<[string, string]>,
  queryTargets: string[]
} {
  const sizes = { easy: 8, medium: 15, hard: 25 };
  const n = sizes[difficulty];

  const tree = new CommandTree();
  const inserts: Array<[string, string]> = [];
  const nodeIds: string[] = ['ROOT'];

  for (let i = 1; i <= n; i++) {
    const parentIndex = Math.floor(Math.random() * nodeIds.length);
    const parent = nodeIds[parentIndex];
    const nodeId = `N${i}`;

    tree.addInsert(nodeId, parent);
    inserts.push([nodeId, parent]);
    nodeIds.push(nodeId);
  }

  tree.computeSizesAndDepths();

  const shuffled = [...inserts].sort(() => Math.random() - 0.5);

  const queryCount = Math.min(3, Math.floor(n / 3));
  const queryTargets = nodeIds
    .filter(id => id !== 'ROOT')
    .sort(() => Math.random() - 0.5)
    .slice(0, queryCount);

  return { groundTruth: tree, shuffledInserts: shuffled, queryTargets };
}
